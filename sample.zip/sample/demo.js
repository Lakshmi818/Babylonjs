        var canvas = document.getElementById("renderCanvas");

        var engine = null;
        var scene = null;
        var sceneToRender = null;
        var createDefaultEngine = function() { return new BABYLON.Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true,  disableWebGL2Support: false}); };
        const createScene = function () {
	const scene = new BABYLON.Scene(engine);
    const ground = BABYLON.MeshBuilder.CreateGround("ground", {width:10, height:10});

	const camera = new BABYLON.ArcRotateCamera("Camera", 3 * Math.PI / 2, Math.PI / 2, 70, BABYLON.Vector3.Zero());
	camera.attachControl(canvas, true);

	const light = new BABYLON.HemisphericLight("hemi", new BABYLON.Vector3(0, 1, 0));
    const cone = BABYLON.MeshBuilder.CreateSphere("sphere", {diameter: 5, diameterX: 5}, scene);
    cone.position.y=1
    cone.position.z=1
    cone.position.x=20

	const fountainProfile = [
		new BABYLON.Vector3(0, 0, 0),
		new BABYLON.Vector3(10, 0, 0),
        new BABYLON.Vector3(10, 4, 0),
		new BABYLON.Vector3(8, 4, 0),
        new BABYLON.Vector3(8, 1, 0),
        new BABYLON.Vector3(1, 2, 0),
		new BABYLON.Vector3(1, 15, 0),
		new BABYLON.Vector3(3, 17, 0)
	];
	
	const fountain = BABYLON.MeshBuilder.CreateLathe("fountain", {shape: fountainProfile, sideOrientation: BABYLON.Mesh.DOUBLESIDE}, scene);
	fountain.position.y = -5;
    scene.onKeyboardObservable.add((keyInfo) => {
        switch (keyInfo.type) {
            case BABYLON.KeyboardEventTypes.KEYDOWN:
                switch (keyInfo.event.key) {
                    case "a":
                    case "A":
                        cone.moveWithCollisions(new BABYLON.Vector3(0.1, 0, 0));
                    break;
                    case "d":
                    case "D":
                        cone.moveWithCollisions(new BABYLON.Vector3(-0.1, 0, 0));
                    break;
                    case "w":
                    case "W":
                        cone.moveWithCollisions(new BABYLON.Vector3(0, 0, -0.1));
                    break;
                    case "s":
                    case "S":
                        cone.moveWithCollisions(new BABYLON.Vector3(0, 0,0.1));
                    break;
                }
            break;
        }
    });
    
    var particleSystem = new BABYLON.ParticleSystem("particles", 5000, scene);

    particleSystem.particleTexture = new BABYLON.Texture("textures/flare.png", scene);

    particleSystem.emitter = new BABYLON.Vector3(0, 10, 0); 
    particleSystem.minEmitBox = new BABYLON.Vector3(-1, 0, 0); 
    particleSystem.maxEmitBox = new BABYLON.Vector3(1, 0, 0); 

    
    particleSystem.color1 = new BABYLON.Color4(0.7, 0.8, 1.0, 1.0);
    particleSystem.color2 = new BABYLON.Color4(0.2, 0.5, 1.0, 1.0);
    particleSystem.colorDead = new BABYLON.Color4(0, 0, 0.2, 0.0);

    particleSystem.minSize = 0.1;
    particleSystem.maxSize = 0.5;

    particleSystem.minLifeTime = 2;
    particleSystem.maxLifeTime = 3.5;

    particleSystem.emitRate = 1500;

    particleSystem.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;

    particleSystem.gravity = new BABYLON.Vector3(0, -9.81, 0);

    particleSystem.direction1 = new BABYLON.Vector3(-2, 8, 2);
    particleSystem.direction2 = new BABYLON.Vector3(2, 8, -2);

    particleSystem.minAngularSpeed = 0;
    particleSystem.maxAngularSpeed = Math.PI;


    particleSystem.minEmitPower = 1;
    particleSystem.maxEmitPower = 3;
    particleSystem.updateSpeed = 0.025;

    particleSystem.start();


	return scene;
}
                var engine;
                var scene;
                initFunction = async function() {               
                    var asyncEngineCreation = async function() {
                        try {
                        return createDefaultEngine();
                        } catch(e) {
                        console.log("the available createEngine function failed. Creating the default engine instead");
                        return createDefaultEngine();
                        }
                    }

                    engine = await asyncEngineCreation();
        if (!engine) throw 'engine should not be null.';
        scene = createScene();};
        initFunction().then(() => {sceneToRender = scene        
            engine.runRenderLoop(function () {
                if (sceneToRender && sceneToRender.activeCamera) {
                    sceneToRender.render();
                }
            });
        });

        window.addEventListener("resize", function () {
            engine.resize();
        });